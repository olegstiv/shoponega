<?php
// Heading
$_['heading_title']     = 'Отчёт об онлайн пользователях';

// Text
$_['text_list']         = 'Список онлайн покупателей';
$_['text_guest']        = 'Гость';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Покупатель';
$_['column_url']        = 'Последняя посещенная страница';
$_['column_referer']    = 'Откуда пришёл';
$_['column_date_added'] = 'Последний клик';
$_['column_action']     = 'Действие';

// Entry
$_['entry_ip']          = 'IP адрес:';
$_['entry_customer']    = 'Покупатель:';