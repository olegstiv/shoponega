<?php
// Heading
$_['heading_title']     = 'Панель управления';

// Text
$_['text_success']      = 'Список панелей успешно отредактирован!';
$_['text_list']         = 'Список панелей';

// Column
$_['column_name']       = 'Название Панели';
$_['column_width']      = 'Ширина';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'Внимание: У вас нет разрешения на изменение панели управления!';