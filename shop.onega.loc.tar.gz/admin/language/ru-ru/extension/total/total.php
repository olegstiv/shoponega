<?php
// Heading
$_['heading_title']    = 'Итого';

// Text
$_['text_extension']   = 'Общая сумма заказа';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     = 'Статус:';
$_['entry_sort_order'] = 'Порядок сортировки:';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
