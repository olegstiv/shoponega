<?php
// Heading
$_['heading_title']  = 'Дополнения';

// Text
$_['text_success']   = 'Дополнение успешно изменено!';
$_['text_list']      = 'Список дополнений';
$_['text_type']      = 'Выберите дополнение из списка:';
$_['text_filter']    = 'Фильтр';
$_['text_analytics'] = 'Каналы продвижения';
$_['text_captcha']   = 'Captcha';
$_['text_dashboard'] = 'Панель управления';
$_['text_feed']      = 'Отзывы';
$_['text_fraud']     = 'Защита от мошенничества';
$_['text_module']    = 'Модули';
$_['text_content']   = 'Модули контента';
$_['text_menu']      = 'Модули меню';
$_['text_payment']   = 'Платежи';
$_['text_shipping']  = 'Доставка';
$_['text_theme']     = 'Шаблоны';
$_['text_total']     = 'Заказы';
